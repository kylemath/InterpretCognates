# Contributors

Name | GitHub user | Description | Role
--- | --- | --- | ---
Søren Wichmann | | | Author, Distributor, DataCurator, Editor, DataCollector
André Müller | | | DataCollector
Ann-Katrin Wett | | | DataCollector
Viveka Velupillai | | | DataCollector
Julia Bischoffberger | | | DataCollector
Eric W. Holman | | | Author, Editor
Cecil H. Brown | | | DataCollector, Author, Editor
Sebastian Sauppe | | | DataCollector
Zarina Molochieva | | | DataCollector
Pamela Brown | | | DataCollector
Oleg Belyaev | | | DataCollector
Johann-Mattis List | @LinguList | | DataCollector
Dmitry Egorov | | | DataCollector
Matthias Urban | | | DataCollector
Robert Mailhammer | | | DataCollector
Agustina Carrizo | | | DataCollector
Matthew S. Dryer | | | DataCollector
Evgenia Korovina | | | DataCollector
David Beck | | | DataCollector
Helen Geyer | | | DataCollector
Patience Epps | | | DataCollector
Anthony Grant | | | DataCollector
Arjan Mossel | | | DataCollector
Darja Appelganz | | | DataCollector
Dickson Pagente | | | DataCollector
Danli Wu | | | DataCollector
Guillaume Segerer | | | DataCollector
Ke Xu | | | DataCollector
Mark Donohue | | | DataCollector
Matthias Pache | | | DataCollector
Pengfei Chen | | | DataCollector
Paul Sidwell | | | DataCollector
Qibin Ran | | | DataCollector
Tessa de Mol-van Valen | | | DataCollector
Yuzhu Liang | | | DataCollector
Yue Sun | | | DataCollector
Robert Forkel | @xrotwang | patron, code | Other
Tiago Tresoldi | @tresoldi | profile, language mapping refinement | Other
