The database of the Automated Similarity Judgment Program (ASJP) aims to
contain 40-item word lists of all the world's languages.
